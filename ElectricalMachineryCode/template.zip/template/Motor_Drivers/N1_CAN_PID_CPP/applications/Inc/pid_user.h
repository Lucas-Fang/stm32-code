#ifndef __PID_USER_H_
#define __PID_USER_H_

#ifdef __cplusplus
extern "C" 
{
#endif

#include "startup_main.h"

//����class PID_Controller
#include "pid.h"
/*******??*******/	
extern PID_Controller pid_controller;
	

#ifdef __cplusplus
}
#endif

#endif
