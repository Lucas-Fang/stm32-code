1. 工程名: CAN_PID_CPP
2. 版本: v1.0
3. 版本状态: 预发行版本
4. 作者: Tung Chia-hui
5. 网站: https://github.com/tungchiahui
6. 电子邮箱: tungchiahui@gmail.com
7. 组织: VinciRobot
8. 构建日期: 2024-02-05