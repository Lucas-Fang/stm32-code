1. Project Name: CAN_PID_CPP
2. Version: v1.0
3. State: Pre-Release
4. Author: Tung Chia-hui
5. Website: https://github.com/tungchiahui
6. E-mail: tungchiahui@gmail.com
7. Organization: VinciRobot
8. Date: 2024-02-05