<<<<<<< HEAD
#ifndef __TIMER_USER_H_
#define __TIMER_USER_H_

#ifdef __cplusplus
extern "C" 
{
#endif

#include "startup_main.h"

	
	
	
	

#ifdef __cplusplus
}
#endif

#endif
=======
#ifndef __TIMER_USER_H_
#define __TIMER_USER_H_

#ifdef __cplusplus
extern "C" 
{
#endif

#include "startup_main.h"

	
	
	
	

#ifdef __cplusplus
}
#endif

#endif
>>>>>>> 00ac74e (9.6)
