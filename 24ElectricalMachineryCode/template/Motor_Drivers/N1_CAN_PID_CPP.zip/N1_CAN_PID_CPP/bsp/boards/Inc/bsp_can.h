<<<<<<< HEAD
#ifndef __BSP_CAN_H_
#define __BSP_CAN_H_

#ifdef __cplusplus
extern "C" 
{
#endif

#include "startup_main.h"

//��CAN_BUS������
#include "can_receive.h"
	
	
	
	

#ifdef __cplusplus
}
#endif

#endif
=======
#ifndef __BSP_CAN_H_
#define __BSP_CAN_H_

#ifdef __cplusplus
extern "C" 
{
#endif

#include "startup_main.h"

//��CAN_BUS������
#include "can_receive.h"
	
	
	
	

#ifdef __cplusplus
}
#endif

#endif
>>>>>>> 00ac74e (9.6)
